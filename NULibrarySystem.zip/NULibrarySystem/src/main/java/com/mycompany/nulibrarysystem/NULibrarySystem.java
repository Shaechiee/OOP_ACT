/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nulibrarysystem;

/**
 *
 * @author Jianna Ramos
 */
public class NULibrarySystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
