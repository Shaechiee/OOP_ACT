

package com.mycompany.activity1oop;

public class Activity1OOP {

    public static void main(String[] args) {
        System.out.println("");
    }
}
